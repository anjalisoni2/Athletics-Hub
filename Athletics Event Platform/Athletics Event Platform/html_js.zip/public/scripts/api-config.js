// API Configuration - Centralized backend URL management

// Determine the API base URL based on environment
export function getAPIBaseURL() {
  const deployedBackend = 'https://athleticseventbackend-production.up.railway.app';
  const localBackend = 'http://127.0.0.1:8000';
  
  // Auto-detect environment
  // If we are on localhost, use the local backend
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    return localBackend;
  }
  
  // If we are opening the file directly or on another system, 
  // use the deployed backend so everyone shares the same data.
  return deployedBackend;
}

// Helper function to build API endpoints
export function getAPIEndpoint(path) {
  return `${getAPIBaseURL()}${path}`;
}
