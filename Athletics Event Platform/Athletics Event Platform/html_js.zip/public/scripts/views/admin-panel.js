// admin-panel.js

import { createIcon, formatNumber, formatDateShort, switchTab } from "../utils.js";
import { mockEvents } from "../data.js";
import { getRegistrations, getOrganizerApprovals, approveOrganizer, rejectOrganizer as rejectOrganizerFromStorage } from "../storage.js";
import { getAPIEndpoint } from "../api-config.js";


// 🔐 Make functions global (for onclick)
window.approveOrganization = approveOrganization;
window.rejectOrganization = rejectOrganization;

// User statistics navigation
window.viewUserStats = function () {
    if (window.navigateTo) {
        navigateTo('user-statistics');
    } else {
        console.error("Navigation function not available");
    }
};

// Event review handler
window.reviewEventApprovals = function () {
    if (window.navigateTo) {
        navigateTo('admin-panel');
        // Then switch to events tab
        setTimeout(() => {
            switchTab('adminTabs', 'events');
        }, 0);
    }
};

// Organizers report handler
window.viewOrganizersReport = function () {
    if (window.navigateTo) {
        navigateTo('organizers-report');
    } else {
        console.error("Navigation function not available");
    }
};

async function approveOrganization(id) {
    try {
        await fetch(getAPIEndpoint(`/api/organizers/${id}/approve/`), { method: "POST" });
        await renderAdminPanel(document.getElementById("app"));
    } catch (err) {
        console.error("Failed to approve organization", err);
    }
}

async function rejectOrganization(id) {
    try {
        await fetch(getAPIEndpoint(`/api/organizers/${id}/reject/`), { method: "POST" });
        await renderAdminPanel(document.getElementById("app"));
    } catch (err) {
        console.error("Failed to reject organization", err);
    }
}

async function loadPendingEvents() {
    try {
        const res = await fetch(getAPIEndpoint("/api/pending-events/"));
        if (!res.ok) {
            console.warn("API returned error status:", res.status);
            return [];
        }
        const data = await res.json();
        return Array.isArray(data) ? data : [];
    } catch (err) {
        console.warn("Failed to fetch pending events (using empty array):", err.message);
        return [];
    }
}



async function approveEvent(id) {
    try {
        const response = await fetch(getAPIEndpoint(`/api/events/${id}/approve/`), {
            method: "POST"
        });

        if (!response.ok) {
            throw new Error(`Failed to approve event: ${response.status}`);
        }

        // Refresh admin panel to update pending events list
        await renderAdminPanel(document.getElementById("app"));

        // Redirect to user events page which will fetch updated approved events
        if (window.navigateTo) {
            navigateTo('events');
        } else {
            window.location.href = '/events.html';
        }
    } catch (err) {
        console.error("Error approving event:", err);
        alert("Failed to approve event. Please try again.");
    }
}



async function rejectEvent(id) {
    try {
        const response = await fetch(getAPIEndpoint(`/api/events/${id}/reject/`), {
            method: "POST"
        });

        if (!response.ok) {
            throw new Error(`Failed to reject event: ${response.status}`);
        }

        // Refresh admin panel to update pending events list
        await renderAdminPanel(document.getElementById("app"));
    } catch (err) {
        console.error("Error rejecting event:", err);
        alert("Failed to reject event. Please try again.");
    }
}

window.approveEvent = approveEvent;
window.rejectEvent = rejectEvent;
window.openEventApprovals = async function () {
    await renderAdminPanel(document.getElementById("app"));
    switchTab('adminTabs', 'events');
};

// Generate monthly revenue data
function generateMonthlyRevenueData() {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    const recentMonths = months.slice(Math.max(0, currentMonth - 5), currentMonth + 1);

    return recentMonths.map((month, index) => ({
        month: month,
        revenue: Math.floor(Math.random() * 45000) + 15000 // Revenue between $15k-$60k
    }));
}

// Generate monthly organizer growth data
function generateMonthlyOrganizerData() {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    const recentMonths = months.slice(Math.max(0, currentMonth - 5), currentMonth + 1);

    return recentMonths.map((month, index) => ({
        month: month,
        organizers: Math.floor(Math.random() * 25) + 5 // New organizers between 5-30
    }));
}

// Create monthly revenue line chart using HTML/CSS
function createMonthlyRevenueChart() {
    const data = generateMonthlyRevenueData();
    const maxRevenue = Math.max(...data.map(d => d.revenue));
    const minRevenue = Math.min(...data.map(d => d.revenue));

    let html = `
        <div style="width: 100%; padding: 30px; background: white; border-radius: 8px; box-sizing: border-box;">
            <!-- Chart Container -->
            <div style="position: relative; width: 100%; height: 300px; background: linear-gradient(180deg, #f9fafb 0%, white 100%); border: 2px solid #e5e7eb; border-radius: 8px; padding: 20px; box-sizing: border-box; margin-bottom: 20px;">
                <!-- Y-axis labels -->
                <div style="position: absolute; left: 0; top: 0; width: 50px; height: 100%; display: flex; flex-direction: column; justify-content: space-between; padding: 20px 5px; text-align: right;">
    `;

    for (let i = 0; i <= 5; i++) {
        const value = maxRevenue - (maxRevenue - minRevenue) / 5 * i;
        html += `<span style="font-size: 11px; color: #6b7280; font-weight: 500;">$${(value / 1000).toFixed(0)}k</span>`;
    }

    html += `
                </div>

                <!-- Data points and lines -->
                <div style="position: relative; width: 100%; height: 100%; margin-left: 50px; display: flex; align-items: flex-end; justify-content: space-around; padding: 0 20px; box-sizing: border-box;">
    `;

    data.forEach((item, idx) => {
        const percentage = ((item.revenue - minRevenue) / (maxRevenue - minRevenue)) * 100;
        html += `
            <div style="display: flex; flex-direction: column; align-items: center; flex: 1; position: relative; margin: 0 5px;">
                <!-- Value label -->
                <span style="position: absolute; bottom: calc(${percentage}% + 15px); font-size: 12px; font-weight: bold; color: #1f2937; white-space: nowrap;">$${(item.revenue / 1000).toFixed(1)}k</span>

                <!-- Dot -->
                <div style="position: absolute; bottom: ${percentage}%; width: 10px; height: 10px; background: #3b82f6; border: 3px solid white; border-radius: 50%; box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3); z-index: 10;"></div>
            </div>
        `;
    });

    html += `
                </div>

                <!-- X-axis -->
                <div style="position: absolute; bottom: 20px; left: 50px; right: 20px; border-bottom: 2px solid #1f2937;"></div>
            </div>

            <!-- Month labels -->
            <div style="display: flex; justify-content: flex-start; padding-left: 50px; gap: 0;">
    `;

    data.forEach((item) => {
        html += `
            <div style="flex: 1; text-align: center; font-size: 11px; font-weight: 600; color: #1f2937; margin: 0 5px;">${item.month}</div>
        `;
    });

    html += `
            </div>

            <!-- Legend -->
            <div style="margin-top: 20px; padding: 15px; background: #f3f4f6; border-left: 4px solid #3b82f6; border-radius: 4px;">
                <strong style="color: #1f2937;">Monthly Revenue Trend</strong>
                <p style="margin: 5px 0 0 0; font-size: 13px; color: #6b7280;">Revenue pattern over the last 6 months showing growth and trends</p>
            </div>
        </div>
    `;

    return html;
}

// Create organizer growth bar chart using HTML/CSS
function createOrganizerGrowthChart() {
    const data = generateMonthlyOrganizerData();
    const maxOrganizers = Math.max(...data.map(d => d.organizers));

    let html = `
        <div style="width: 100%; padding: 30px; background: white; border-radius: 8px; box-sizing: border-box;">
            <!-- Chart Container -->
            <div style="position: relative; width: 100%; height: 300px; background: linear-gradient(180deg, #f9fafb 0%, white 100%); border: 2px solid #e5e7eb; border-radius: 8px; padding: 20px; box-sizing: border-box; margin-bottom: 20px;">
                <!-- Y-axis labels -->
                <div style="position: absolute; left: 0; top: 0; width: 50px; height: 100%; display: flex; flex-direction: column; justify-content: space-between; padding: 20px 5px; text-align: right;">
    `;

    for (let i = 0; i <= 5; i++) {
        const value = Math.round((maxOrganizers / 5) * (5 - i));
        html += `<span style="font-size: 11px; color: #6b7280; font-weight: 500;">${value}</span>`;
    }

    html += `
                </div>

                <!-- Bars -->
                <div style="position: relative; width: 100%; height: 100%; margin-left: 50px; display: flex; align-items: flex-end; justify-content: space-around; padding: 0 20px; box-sizing: border-box;">
    `;

    data.forEach((item, idx) => {
        const percentage = (item.organizers / maxOrganizers) * 100;
        html += `
            <div style="display: flex; flex-direction: column; align-items: center; flex: 1; margin: 0 5px;">
                <!-- Bar -->
                <div style="width: 100%; max-width: 45px; height: ${percentage}%; background: linear-gradient(180deg, #10b981 0%, #059669 100%); border-radius: 6px 6px 0 0; box-shadow: 0 4px 8px rgba(16, 185, 129, 0.2); transition: all 0.3s ease; cursor: pointer;"
                     onmouseover="this.style.boxShadow='0 8px 16px rgba(16, 185, 129, 0.4)'; this.style.transform='scaleY(1.05)';"
                     onmouseout="this.style.boxShadow='0 4px 8px rgba(16, 185, 129, 0.2)'; this.style.transform='scaleY(1)';">
                </div>

                <!-- Value label -->
                <span style="margin-top: 12px; font-size: 13px; font-weight: bold; color: #1f2937;">${item.organizers}</span>

                <!-- Month label -->
                <span style="margin-top: 6px; font-size: 11px; font-weight: 600; color: #6b7280;">${item.month}</span>
            </div>
        `;
    });

    html += `
                </div>

                <!-- X-axis -->
                <div style="position: absolute; bottom: 20px; left: 50px; right: 20px; border-bottom: 2px solid #1f2937;"></div>
            </div>

            <!-- Legend -->
            <div style="margin-top: 20px; padding: 15px; background: #f0fdf4; border-left: 4px solid #10b981; border-radius: 4px;">
                <strong style="color: #1f2937;">New Organizers Per Month</strong>
                <p style="margin: 5px 0 0 0; font-size: 13px; color: #6b7280;">Shows the number of new organizers joining the platform each month</p>
            </div>
        </div>
    `;

    return html;
}


// ✅ EXPORT FUNCTION
export async function renderAdminPanel(container) {
    // Show loading state immediately to prevent blank screen
    container.innerHTML = `
        <div class="flex items-center justify-center" style="min-height: 50vh; flex-direction: column; gap: 1rem;">
            <div class="spinner"></div>
            <p class="text-gray-600 animate-pulse">Loading dashboard data from server...</p>
        </div>
    `;

    const pendingEvents = await loadPendingEvents();

    // Fetch approved events with proper error handling
    let approvedEvents = [];
    try {
        const response = await fetch(getAPIEndpoint("/api/approved-events/"));
        if (response.ok) {
            approvedEvents = await response.json();
        } else {
            console.warn("API returned error status:", response.status);
        }
    } catch (err) {
        console.error("Failed to fetch approved events:", err);
    }

    // Fetch pending organizers from backend API
    let pendingOrganizers = [];
    try {
        const orgRes = await fetch(getAPIEndpoint("/api/organizers/pending/"));
        if (orgRes.ok) {
            pendingOrganizers = await orgRes.json();
        }
    } catch (err) {
        console.error("Failed to fetch pending organizers:", err);
    }

    // Calculate dynamic platform stats from real data
    const registrations = getRegistrations();
    const users = JSON.parse(localStorage.getItem("users") || "{}");
    const totalUsers = Object.keys(users).length + registrations.length; // Users + unique registrants
    const totalEvents = mockEvents.length + approvedEvents.length;

    // Calculate total revenue from registrations
    const totalRevenue = registrations.reduce((sum, reg) => {
        const amount = parseFloat(reg.amount || 0);
        return sum + (isNaN(amount) ? 0 : amount);
    }, 0);

    // Count active events (upcoming or active status)
    const activeEvents = mockEvents.filter(e => e.status === 'active' || e.status === 'upcoming').length;

    // Count pending approvals (pending organizers + pending events)
    const pendingOrgsCount = pendingOrganizers.length;
    const pendingApprovals = pendingOrgsCount + pendingEvents.length;

    // Calculate system health based on data availability
    const systemHealth = totalUsers > 0 && totalEvents > 0 ? 99.8 : 95.0;


    const platformStats = {
        totalUsers: totalUsers,
        totalEvents: totalEvents,
        totalRevenue: totalRevenue,
        activeEvents: activeEvents,
        pendingApprovals: pendingApprovals,
        systemHealth: systemHealth
    };

    container.innerHTML = `
        <div class="bg-gray-50" style="min-height: 100vh; padding: 2rem 0;">
            <div class="container">
                <!-- Header -->
                <div class="mb-8">
                    <div class="flex items-center gap-3 mb-2">
                        <div style="width: 40px; height: 40px; color: var(--primary-blue);">
                            ${createIcon('shield').outerHTML}
                        </div>
                        <h1 class="text-4xl font-bold">Admin Panel</h1>
                    </div>
                    <p class="text-xl text-gray-600">Platform-wide management and monitoring</p>
                </div>

                <!-- Stats Overview -->
                <div class="grid grid-md-2 grid-lg-4 gap-6 mb-8">
                    <div class="dashboard-stat">
                        <div class="stat-header">
                            <div class="stat-title">Total Users</div>
                            <div class="stat-icon">${createIcon('users').outerHTML}</div>
                        </div>
                        <div class="stat-number">${formatNumber(platformStats.totalUsers)}</div>
                        <div class="stat-change positive">+${formatNumber(Math.round(platformStats.totalUsers * 0.15))} this month</div>
                    </div>

                    <div class="dashboard-stat">
                        <div class="stat-header">
                            <div class="stat-title">Platform Events</div>
                            <div class="stat-icon">${createIcon('calendar').outerHTML}</div>
                        </div>
                        <div class="stat-number">${formatNumber(platformStats.totalEvents)}</div>
                        <div class="stat-change positive">+${platformStats.activeEvents} active now</div>
                    </div>

                    <div class="dashboard-stat">
                        <div class="stat-header">
                            <div class="stat-title">Total Revenue</div>
                            <div class="stat-icon">${createIcon('dollarSign').outerHTML}</div>
                        </div>
                        <div class="stat-number">$${platformStats.totalRevenue > 999999 ? (platformStats.totalRevenue / 1000000).toFixed(2) + 'M' : formatNumber(Math.round(platformStats.totalRevenue))}</div>
                        <div class="stat-change positive">${platformStats.totalRevenue > 0 ? '✓ Revenue Active' : 'No data yet'}</div>
                    </div>

                    <div class="dashboard-stat">
                        <div class="stat-header">
                            <div class="stat-title">System Health</div>
                            <div class="stat-icon">${createIcon('activity').outerHTML}</div>
                        </div>
                        <div class="stat-number">${platformStats.systemHealth}%</div>
                        <div class="stat-change positive">${platformStats.pendingApprovals} pending</div>
                    </div>
                </div>

                <!-- Tabs -->
                <div class="tabs" id="adminTabs">
                    <div class="tabs-list">
                        <button class="tab-trigger active" data-tab="overview" onclick="switchTab('adminTabs', 'overview')">Overview</button>
                        <button class="tab-trigger" data-tab="organizations" onclick="switchTab('adminTabs', 'organizations')">Organization Approvals</button>
                       <button class="tab-trigger" data-tab="events" onclick="openEventApprovals()">Event Approvals</button>
                       <button class="tab-trigger" data-tab="reports" onclick="switchTab('adminTabs', 'reports')">Reports</button>
                    </div>

                    <!-- Overview Tab -->
                    <div class="tab-content active" id="overview">
                        <div class="grid grid-lg-2 gap-6 mb-6">
                            <!-- Pending Actions -->
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Pending Actions</div>
                                    <div class="card-description">Items requiring your attention</div>
                                </div>
                                <div class="card-content">
                                    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                                        <div class="flex items-center justify-between p-3 rounded-lg" style="background: #dbeafe; border: 1px solid #bfdbfe;">
                                            <div class="flex items-center gap-3">
                                                ${createIcon('users').outerHTML}
                                                <div>
                                                    <p class="font-medium">User Reports</p>
                                                    <p class="text-sm text-gray-600">8 support tickets open</p>
                                                </div>
                                            </div>
                                            <button class="btn btn-outline btn-sm" onclick="viewUserStats()">View</button>
                                        </div>

                                        <div class="flex items-center justify-between p-3 rounded-lg" style="background: #dcfce7; border: 1px solid #bbf7d0;">
                                            <div class="flex items-center gap-3">
                                                ${createIcon('briefcase').outerHTML}
                                                <div>
                                                    <p class="font-medium">Organizers Report</p>
                                                    <p class="text-sm text-gray-600">12 organizer accounts pending review</p>
                                                </div>
                                            </div>
                                            <button class="btn btn-outline btn-sm" onclick="viewOrganizersReport()">View</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Recent Activity -->
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Recent Activity</div>
                                    <div class="card-description">Latest platform activities</div>
                                </div>
                                <div class="card-content">
                                    <div style="display: flex; flex-direction: column; gap: 1rem;">
                                        ${[
            { action: 'New event created', user: 'NYC Running Club', time: '5 min ago', type: 'event' },
            { action: 'User registration', user: 'john.doe@email.com', time: '12 min ago', type: 'user' },
            { action: 'Event approved', user: 'Mountain Sports Assoc.', time: '23 min ago', type: 'approval' },
            { action: 'Payment processed', user: 'Event #1247', time: '1 hour ago', type: 'payment' },
            { action: 'Support ticket resolved', user: 'Ticket #8842', time: '2 hours ago', type: 'support' }
        ].map(activity => `
                                            <div class="flex items-center gap-3 text-sm">
                                                <div class="activity-dot ${activity.type}"></div>
                                                <div style="flex: 1;">
                                                    <p class="font-medium">${activity.action}</p>
                                                    <p class="text-xs text-gray-500">${activity.user}</p>
                                                </div>
                                                <span class="text-xs text-gray-400">${activity.time}</span>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Platform Analytics -->
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Platform Analytics</div>
                            </div>
                            <div class="card-content">
                                <div class="grid grid-md-3 gap-6">
                                    <div class="metric-card blue">
                                        <div class="metric-icon blue">${createIcon('globe').outerHTML}</div>
                                        <div class="metric-value blue">45+</div>
                                        <div class="metric-label">Countries</div>
                                    </div>
                                    <div class="metric-card green">
                                        <div class="metric-icon green">${createIcon('trendingUp').outerHTML}</div>
                                        <div class="metric-value green">892K</div>
                                        <div class="metric-label">Total Participants</div>
                                    </div>
                                    <div class="metric-card purple">
                                        <div class="metric-icon purple">${createIcon('activity').outerHTML}</div>
                                        <div class="metric-value purple">24/7</div>
                                        <div class="metric-label">Uptime</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Organization Approvals Tab -->
<div class="tab-content" id="organizations">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Organization Approvals</div>
            <div class="card-description">
                Approve or reject organizer accounts
            </div>
        </div>

        <div class="card-content">
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                ${pendingOrganizers.length === 0
            ? `<p class="text-gray-500">No pending organizer requests</p>`
            : pendingOrganizers.map(org => `
                            <div class="flex items-center justify-between p-4 border rounded-lg">
                                <div>
                                    <h4 class="font-semibold">${org.name}</h4>
                                    <p class="text-sm text-gray-600">${org.email}</p>
                                    <p class="text-xs text-gray-500">@${org.username}</p>
                                    <span class="badge badge-warning">pending</span>
                                </div>
                                <div class="flex gap-2">
                                    <button class="btn btn-outline btn-sm"
                                        style="color: var(--success-green); border-color: var(--success-green);"
                                        onclick="approveOrganization(${org.id})">
                                        Approve
                                    </button>
                                    <button class="btn btn-outline btn-sm"
                                        style="color: var(--danger-red); border-color: var(--danger-red);"
                                        onclick="rejectOrganization(${org.id})">
                                        Reject
                                    </button>
                                </div>
                            </div>
                        `).join("")}
            </div>
        </div>
    </div>
</div>


                    <!-- Event Approvals Tab -->
<div class="tab-content" id="events">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Event Approval Queue</div>
            <div class="card-description">Review and approve pending events</div>
        </div>

        <div class="card-content">
            <div style="display:flex; flex-direction:column; gap:1rem;">
                ${pendingEvents.length === 0
            ? `<p class="text-gray-500">No pending events</p>`
            : pendingEvents.map(event => `
                        <div class="flex items-center justify-between p-4 border rounded-lg">
                            <div class="flex items-center gap-4">
                                <img 
                                    src="${event.imageUrl}" 
                                    alt="${event.title}"
                                    style="width:80px;height:80px;border-radius:8px;object-fit:cover;"
                                >
                                <div>
                                    <h4 class="font-semibold">${event.title}</h4>
                                    <p class="text-sm text-gray-600">${event.organizer}</p>
                                    <div class="flex gap-3 text-sm mt-2">
                                        <span>${formatDateShort(event.date)}</span>
                                        <span>Max ${event.maxParticipants}</span>
                                        <span>${event.price} ${event.currency}</span>
                                    </div>
                                </div>
                            </div>

                            <div class="flex gap-2">
                            <button onclick="approveEvent(${event.id})" class="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg
                            hover:bg-green-700 active:scale-95 transition">
                                Approve
                            </button>

                            <button onclick="rejectEvent(${event.id})" class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-lg
                            hover:bg-red-700 active:scale-95 transition">
                                Reject
                            </button>
                    </div>

                        </div>
                    `).join("")}
            </div>
        </div>
    </div>
</div>

                    <!-- Reports Tab -->
                    <div class="tab-content" id="reports">
                        <div class="grid grid-lg-2 gap-6 mb-6">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Monthly Revenue</div>
                                    <div class="card-description">Revenue generated over the last 6 months</div>
                                </div>
                                <div class="card-content" style="padding: 0; background: #ffffff; overflow: visible;">
                                    ${createMonthlyRevenueChart()}
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Organizer Growth</div>
                                    <div class="card-description">New organizers joining per month</div>
                                </div>
                                <div class="card-content" style="padding: 0; background: #ffffff; overflow: visible;">
                                    ${createOrganizerGrowthChart()}
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Top Performing Events</div>
                            </div>
                            <div class="card-content">
                                <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                                    ${mockEvents
            .map(event => ({
                ...event,
                revenue: event.participants * event.price
            }))
            .sort((a, b) => b.revenue - a.revenue)
            .slice(0, 5)
            .map((event, idx) => `
                                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                                <div class="flex items-center gap-3">
                                                    <div style="width: 32px; height: 32px; background: var(--primary-blue); color: white; border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center; font-weight: 700;">
                                                        #${idx + 1}
                                                    </div>
                                                    <div>
                                                        <p class="font-medium">${event.title}</p>
                                                        <p class="text-sm text-gray-600">${event.participants} participants</p>
                                                    </div>
                                                </div>
                                                <div class="text-right">
                                                    <p class="font-bold" style="color: var(--success-green);">$${formatNumber(Math.round(event.revenue))}</p>
                                                    <p class="text-xs text-gray-500">Revenue</p>
                                                </div>
                                            </div>
                                        `).join('')}
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    `;
}
