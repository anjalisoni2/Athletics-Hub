// event-details.js
// FULL UI + modern tab design + supports BOTH mockEvents + backend approved events

import { mockEvents } from "../data.js";
import { getAPIEndpoint } from "../api-config.js";

/* ================= HELPER FUNCTIONS ================= */

// Geocode location name to coordinates using Nominatim (OpenStreetMap)
async function geocodeLocation(locationName) {
  if (!locationName || locationName.trim() === '') throw new Error('Location name is empty');

  try {
    const encodedLocation = encodeURIComponent(locationName);
    const url = `https://nominatim.openstreetmap.org/search?q=${encodedLocation}&format=json&limit=1`;

    const response = await fetch(url, {
      headers: { 'User-Agent': 'AthleticsHub-App' }
    });

    if (!response.ok) throw new Error('Geocoding API error');
    const data = await response.json();

    if (data && data.length > 0) {
      const result = data[0];
      return {
        lat: parseFloat(result.lat),
        lng: parseFloat(result.lon),
        name: locationName,
        displayName: result.display_name
      };
    } else throw new Error(`No results found for "${locationName}"`);
  } catch (err) {
    console.error(`Geocoding error for "${locationName}":`, err);
    throw new Error(`Could not find coordinates for "${locationName}"`);
  }
}

/* ================= API ================= */

async function getApprovedEvents() {
  try {
    const res = await fetch(getAPIEndpoint('/api/approved-events/'));
    if (!res.ok) throw new Error('Failed to fetch approved events');
    const data = await res.json();

    return data.map(ev => ({
      id: String(ev.id),
      title: ev.title || 'Untitled Event',
      description: ev.description || 'No description available.',
      date: ev.date,
      location: ev.location || 'Location TBA',
      imageUrl: ev.imageUrl || "https://placehold.co/1200x400?text=Event+Image",
      category: 'Running',
      status: 'upcoming',
      price: ev.price ?? 0,
      currency: 'USD',
      participants: ev.participants ?? 0,
      maxParticipants: ev.maxParticipants ?? 200,
      distance: ev.distance || '—',
      organizer: ev.organizer || 'Event Organizer',
      registrationDeadline: ev.registrationDeadline || 'N/A'
    }));

  } catch (err) {
    console.error("event-details fetch error:", err);
    return [];
  }
}

/* ================= STATE ================= */

let isRegistered = false;
let activeTab = "overview";

// Load past event images from localStorage (persistent)
let pastEventImages = JSON.parse(localStorage.getItem("pastEventImages") || "[]");

/* ================= MAIN RENDER ================= */

export async function renderEventDetails(container, eventId) {
  const app = document.getElementById("app");
  const approvedEvents = await getApprovedEvents();
  const allEvents = [...mockEvents, ...approvedEvents];
  const event = allEvents.find(e => String(e.id) === String(eventId));

  if (!event) {
    app.innerHTML = `<h2>Event not found</h2>`;
    return;
  }

  // Get current user's role
  const currentUser = localStorage.getItem("currentUser");
  const users = JSON.parse(localStorage.getItem("users")) || {};
  let userRole = "guest";
  if (currentUser && users[currentUser]) {
    userRole = users[currentUser].role;
  }
  const isAthlete = userRole === "participant" || userRole === "athlete";

  const participationPercentage = Math.round((event.participants / event.maxParticipants) * 100);

  app.innerHTML = `
    <style>
      /* Modern Tab Styles */
      .tabs {
        display: flex;
        gap: 16px;
        border-bottom: 2px solid #e5e7eb;
        margin-top: 20px;
        overflow-x: auto;
        scrollbar-width: none;
      }
      .tabs::-webkit-scrollbar { display: none; }
      .tabBtn {
        background: none;
        border: none;
        padding: 12px 16px;
        font-size: 15px;
        font-weight: 500;
        cursor: pointer;
        color: #6b7280;
        position: relative;
        transition: color 0.2s;
      }
      .tabBtn:hover { color: #2563eb; }
      .tabBtn.active::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: -2px;
        width: 100%;
        height: 3px;
        background-color: #2563eb;
        border-radius: 3px 3px 0 0;
      }
    </style>

    <div style="max-width:1200px;margin:0 auto;padding:16px">

      <!-- Back -->
      <button id="backBtn" style="
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  font-size: 15px;
  font-weight: 500;
  color: #2563eb;
  background-color: #eff6ff;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
  transition: all 0.2s ease;
"
onmouseover="this.style.background='#dbeafe'"
onmouseout="this.style.background='#eff6ff'"
>← Back to Events</button>


      <!-- Banner -->
      <img src="${event.imageUrl}" alt="${event.title}" style="width:100%;height:300px;object-fit:cover;border-radius:14px;margin-bottom:20px" />

      <!-- MAIN GRID -->
      <div style="display:grid;grid-template-columns:${isAthlete ? '2fr 1fr' : '1fr'};gap:24px">

        <!-- LEFT CONTENT -->
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:20px">

          <!-- Header -->
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <h2 style="margin:0">${event.title}</h2>
              <p style="margin:4px 0;color:#6b7280">${event.organizer}</p>
              <span style="background:#dcfce7;color:#166534;padding:4px 10px;border-radius:999px;font-size:12px">
                ${event.status}
              </span>
            </div>
            <div style="display:flex;gap:10px">
              <button>♡</button>
              <button>↗</button>
            </div>
          </div>

          <!-- Tabs -->
          <div class="tabs">
            <button class="tabBtn" data-tab="overview">Overview</button>
            <button class="tabBtn" data-tab="details">Details</button>
            <button class="tabBtn" data-tab="route">Route</button>
            <button class="tabBtn" data-tab="faqs">FAQs</button>
            <button class="tabBtn" data-tab="past">Past Events</button>
          </div>

          <!-- Tab Content -->
          <div class="tabContent" style="margin-top:16px;">
            ${renderTabContent(event)}
          </div>

          <!-- Info Grid -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:20px">
            <div style="border:1px solid #e5e7eb;border-radius:10px;padding:12px">
              <b>Event Date</b><br>${new Date(event.date).toDateString()}
            </div>
            <div style="border:1px solid #e5e7eb;border-radius:10px;padding:12px">
              <b>Location</b><br>${event.location}
            </div>
            <div style="border:1px solid #e5e7eb;border-radius:10px;padding:12px">
              <b>Distance</b><br>${event.distance}
            </div>
            <div style="border:1px solid #e5e7eb;border-radius:10px;padding:12px">
              <b>Registration Deadline</b><br>${event.registrationDeadline}
            </div>
          </div>
        </div>

        <!-- RIGHT REGISTRATION PANEL (Only for Athletes) -->
        ${isAthlete ? `
        <div style="background:white;padding:24px;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,0.08)">
          <h2 style="margin-top:0;color:#2563eb;">Register Now</h2>
          <p style="color:#6b7280;margin-bottom:16px;">Secure your spot today</p>

          <div style="background:#eff6ff;padding:16px;border-radius:12px;margin-bottom:16px;text-align:center;">
            <h3 style="margin:0;color:#1e40af">${event.price} ${event.currency}</h3>
            <span style="font-size:12px;color:#1e40af">Registration Fee</span>
          </div>

          <p id="spotsAvailable" style="margin-bottom:8px;">
            Spots Available: <b>${Math.max(0, event.maxParticipants - event.participants)}</b>
          </p>
          <div style="background:#e5e7eb;height:12px;border-radius:8px;overflow:hidden;margin-bottom:8px;">
            <div id="spotsProgressBar" style="background:#2563eb;height:12px;width:${participationPercentage}%;border-radius:8px;transition: width 0.3s ease;"></div>
          </div>
          <p id="spotsPercentage" style="font-size:12px;color:#6b7280;margin-bottom:16px;">${participationPercentage}% filled</p>

          <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:14px;color:#374151;cursor:pointer;">
              <input type="checkbox" id="rulesCheckbox" />
              I agree to the Event Rules & Guidelines
            </label>
            <a href="docs/Event_Rules_Guidelines.pdf" target="_blank" style="display:block;text-align:center;background:#2563eb;color:white;padding:12px;border-radius:10px;text-decoration:none;font-weight:500;transition:0.2s;"
               onmouseover="this.style.background='#1e40af'" onmouseout="this.style.background='#2563eb'">
              View Guidelines
            </a>
          </div>

          <button id="registerBtn" disabled style="width:100%;background:#9ca3af;color:white;padding:12px;border:none;border-radius:10px;cursor:not-allowed;font-weight:500;">
            Register Now
          </button>
        </div>
        ` : ''}
      </div>
    </div>
  `;

  /* ================= EVENTS ================= */
  document.getElementById("backBtn").onclick = () => navigateTo("events");

  const tabButtons = document.querySelectorAll(".tabBtn");
  tabButtons.forEach(btn => {
    if (btn.dataset.tab === activeTab) btn.classList.add("active");

    btn.onclick = () => {
      activeTab = btn.dataset.tab;
      tabButtons.forEach(t => t.classList.remove("active"));
      btn.classList.add("active");

      document.querySelector(".tabContent").innerHTML = renderTabContent(event);

      // Attach dynamic past event logic
      if (activeTab === "past") {
        renderPastEventImages();
        attachPastEventImageListeners();
      }

      if (activeTab === "route") {
        setTimeout(() => {
          const mapElement = document.getElementById("route-map");
          if (mapElement) {
            if (!window.google || !window.google.maps) {
              setTimeout(() => initializeRouteMap(event), 500);
            } else {
              initializeRouteMap(event);
            }
          }
        }, 300);
      }
    };
  });

  // Only attach registration event listeners if user is an athlete
  if (isAthlete) {
    const rulesCheckbox = document.getElementById("rulesCheckbox");
    const registerBtn = document.getElementById("registerBtn");

    if (rulesCheckbox && registerBtn) {
      rulesCheckbox.addEventListener("change", () => {
        registerBtn.disabled = !rulesCheckbox.checked;
        registerBtn.style.background = rulesCheckbox.checked ? "#2563eb" : "#9ca3af";
        registerBtn.style.cursor = rulesCheckbox.checked ? "pointer" : "not-allowed";
      });
    }

    document.getElementById("registerBtn")?.addEventListener("click", () => {
      const currentUser = localStorage.getItem("currentUser");
      if (!currentUser) {
        alert("Please log in first to register for events");
        window.location.href = 'login.html';
        return;
      }
      window.location.href = `register.html?id=${eventId}`;
    });
  }

  // Initial render for past tab if default is active
  if (activeTab === "past") {
    renderPastEventImages();
    attachPastEventImageListeners();
  }
}

/* ================= TAB CONTENT ================= */
function renderTabContent(event) {
  if (activeTab === "overview") {
    return `<h4>📋 Event Overview</h4><p>${event.description || 'No description available.'}</p>`;
  }
  if (activeTab === "details") {
    return `
      <ul>
        <li>Registration Opens: 6:00 AM</li>
        <li>Event Start: 8:00 AM</li>
        <li>Awards Ceremony: 3:00 PM</li>
        <li>Organizer: ${event.organizer}</li>
      </ul>
    `;
  }
  if (activeTab === "route") {
    return `
      <div id="route-map" style="width:100%;height:400px;border-radius:10px;margin:16px 0;background:#f0f0f0;border:1px solid #ddd;display:flex;align-items:center;justify-content:center;color:#999;font-size:14px;">Loading map...</div>
      <p style="margin-top:12px;color:#6b7280">🗺️ Event route displayed on the map above</p>
    `;
  }
  if (activeTab === "faqs") {
    return `
      <p><b>Can I transfer registration?</b> Yes</p>
      <p><b>What if it rains?</b> Event continues</p>
      <p><b>Age limit?</b> 18+</p>
    `;
  }
  if (activeTab === "past") {
    return `
      <h4 style="color:#2563eb; margin-bottom:16px;">📅 Past Events</h4>
      <div id="pastEventsGrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;">
        <!-- Images rendered dynamically -->
      </div>

      <input
        type="file"
        id="imagePicker"
        accept="image/*"
        multiple
        style="display:none"
      />

      <button id="addPastEventBtn" style="margin-top:16px;padding:8px 12px;font-size:16px;font-weight:bold;border:none;background:#2563eb;color:white;border-radius:8px;cursor:pointer;">
        + Add Past Event
      </button>
      <p style="color:#6b7280;margin-top:12px;">More past events will be added soon!</p>
    `;
  }
  return '';
}

/* ================= PAST EVENTS IMAGE HANDLING ================= */
function attachPastEventImageListeners() {
  const picker = document.getElementById("imagePicker");
  const addBtn = document.getElementById("addPastEventBtn");
  if (!picker || !addBtn) return;

  addBtn.onclick = () => picker.click();

  picker.onchange = (e) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = function (ev) {
        const src = ev.target.result;
        pastEventImages.push(src);
        localStorage.setItem("pastEventImages", JSON.stringify(pastEventImages));
        renderPastEventImages();
      };
      reader.readAsDataURL(file);
    });

    e.target.value = "";
  };
}

function renderPastEventImages() {
  const grid = document.getElementById("pastEventsGrid");
  if (!grid) return;

  grid.innerHTML = pastEventImages.map(src => `
    <img src="${src}" style="width:100%;height:150px;object-fit:cover;border-radius:8px;">
  `).join('');
}


/* ================= EVENT ROUTE PARSING & OSRM ROUTING ================= */

// Parse location string format: "StartPoint to EndPoint" or just "Location"
function parseEventLocations(locationString) {
  if (!locationString) return { start: null, end: null };

  const parts = locationString.split(' to ');

  if (parts.length === 2) {
    return {
      start: parts[0].trim(),
      end: parts[1].trim()
    };
  }

  // If no " to " found, use same location for both
  return {
    start: locationString.trim(),
    end: locationString.trim()
  };
}

// Get user's live location via GPS
function getUserLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      console.warn("Geolocation not supported - using default location");
      // Default fallback location (Ahmedabad, India as example)
      resolve({ lat: 23.0225, lng: 72.5714 });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLat = position.coords.latitude;
        const userLng = position.coords.longitude;
        console.log("User location obtained:", userLat, userLng);
        resolve({ lat: userLat, lng: userLng });
      },
      (error) => {
        console.warn("Geolocation error:", error.message, "- using default location");
        // Default fallback if user denies or location fails
        resolve({ lat: 23.0225, lng: 72.5714 });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  });
}

// Fetch route from OSRM API (free, no API key needed)
async function getOSRMRoute(userLng, userLat, eventLng, eventLat) {
  try {
    // Simple URL format: /route/v1/driving/lon1,lat1;lon2,lat2
    const url = `https://router.project-osrm.org/route/v1/driving/${userLng},${userLat};${eventLng},${eventLat}?overview=full&geometries=geojson`;

    console.log("Fetching OSRM route:", url);

    const response = await fetch(url);
    if (!response.ok) throw new Error("OSRM API error: " + response.status);

    const data = await response.json();
    console.log("OSRM Response:", data);

    if (data.routes && data.routes.length > 0) {
      const route = data.routes[0];
      const distance = (route.distance / 1000).toFixed(2);
      const duration = Math.round(route.duration / 60);

      console.log("Route found - Distance:", distance, "km, Duration:", duration, "minutes");

      return {
        distance: distance,
        duration: duration,
        geometry: route.geometry.coordinates // [lng, lat] pairs
      };
    }
    throw new Error("No routes in OSRM response");
  } catch (err) {
    console.error("OSRM error:", err);
    return null;
  }
}

// Initialize map - Show route from START LOCATION to END LOCATION (event locations)
async function initializeRouteMap(event) {
  const mapElement = document.getElementById("route-map");

  if (!mapElement) {
    console.error("Route map element not found in DOM");
    return;
  }

  if (!window.google || !window.google.maps) {
    console.error("Google Maps API not loaded");
    return;
  }

  // Show loading state
  mapElement.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#999;">🔍 Loading event route...</div>';

  try {
    // STEP 1: Parse start and end locations from event.location string
    // Format: "Start location to End location"
    const parsedLocations = parseEventLocations(event.location);
    console.log("Parsed locations:", parsedLocations);

    // STEP 2: Geocode START location
    mapElement.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#999;">🔍 Finding start location...</div>';

    let startLocation = null;
    try {
      startLocation = await geocodeLocation(parsedLocations.start);
      console.log("Start location:", startLocation);
    } catch (err) {
      console.error("Start location geocoding failed:", err);
      throw new Error(`Start location "${parsedLocations.start}" not found. Please check the spelling.`);
    }

    const startLat = startLocation.lat;
    const startLng = startLocation.lng;

    // STEP 3: Geocode END location
    mapElement.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#999;">🔍 Finding end location...</div>';

    let endLocation = null;
    try {
      endLocation = await geocodeLocation(parsedLocations.end);
      console.log("End location:", endLocation);
    } catch (err) {
      console.error("End location geocoding failed:", err);
      throw new Error(`End location "${parsedLocations.end}" not found. Please check the spelling.`);
    }

    const endLat = endLocation.lat;
    const endLng = endLocation.lng;

    // STEP 4: Calculate center point between start and end
    const center = {
      lat: (startLat + endLat) / 2,
      lng: (startLng + endLng) / 2
    };

    // Clear loading state and create map
    mapElement.innerHTML = '';
    const map = new google.maps.Map(mapElement, {
      zoom: 12,
      center: center,
      mapTypeId: 'roadmap',
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels',
          stylers: [{ visibility: 'off' }]
        }
      ]
    });

    // STEP 5: Fetch route from OSRM - Start Location to End Location
    console.log("Fetching OSRM route from start to end...");
    const routeData = await getOSRMRoute(startLng, startLat, endLng, endLat);

    if (routeData && routeData.geometry) {
      console.log("Route geometry received, drawing polyline...");

      // Convert GeoJSON coordinates to LatLng format
      const pathCoordinates = routeData.geometry.map(coord => ({
        lat: coord[1],
        lng: coord[0]
      }));

      // Draw route polyline (blue line)
      new google.maps.Polyline({
        path: pathCoordinates,
        geodesic: true,
        strokeColor: '#2563eb',
        strokeOpacity: 0.8,
        strokeWeight: 4,
        map: map
      });

      console.log("Polyline drawn, adding markers...");

      // Add START location marker (green)
      new google.maps.Marker({
        position: { lat: startLat, lng: startLng },
        map: map,
        title: `Start: ${startLocation.name}`,
        icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png',
        animation: google.maps.Animation.DROP
      });

      // Add END location marker (red)
      new google.maps.Marker({
        position: { lat: endLat, lng: endLng },
        map: map,
        title: `End: ${endLocation.name}`,
        icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png',
        animation: google.maps.Animation.DROP
      });

      // Add route info box
      addEventRouteInfo(map, routeData.distance, routeData.duration, startLocation.name, endLocation.name);

      console.log(`✓ Route calculated: ${routeData.distance} km, ${routeData.duration} minutes`);
    } else {
      console.warn("Could not fetch OSRM route, showing markers only");

      // Fallback: just show markers without route line
      new google.maps.Marker({
        position: { lat: startLat, lng: startLng },
        map: map,
        title: `Start: ${startLocation.name}`,
        icon: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png'
      });

      new google.maps.Marker({
        position: { lat: endLat, lng: endLng },
        map: map,
        title: `End: ${endLocation.name}`,
        icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
      });

      addEventRouteInfo(map, '—', '—', startLocation.name, endLocation.name);
    }

  } catch (err) {
    console.error("Error initializing map:", err);
    mapElement.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#999;text-align:center;padding:20px;">
      <div>
        <div style="margin-bottom:8px;">⚠️ Could not load the event route</div>
        <div style="font-size:12px;">${err.message}</div>
      </div>
    </div>`;
  }
}

// Display route information for event with start and end locations
function addEventRouteInfo(map, distance, duration, startLocation, endLocation) {
  const infoBox = document.createElement('div');
  infoBox.style.cssText = `
    background: white;
    padding: 16px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 14px;
    margin: 10px;
    max-width: 340px;
    border-left: 4px solid #2563eb;
  `;

  infoBox.innerHTML = `
    <div style="font-weight: 700; margin-bottom: 12px; color: #1f2937; font-size: 15px;">🗺️ Event Route</div>

    <div style="margin: 10px 0; padding: 10px; background: #f0f9ff; border-radius: 6px;">
      <div style="color: #4b5563; font-size: 13px; margin-bottom: 4px;">
        <span style="color: #22c55e;">●</span> <strong>Start:</strong> ${startLocation}
      </div>
      <div style="color: #4b5563; font-size: 13px;">
        <span style="color: #ef4444;">●</span> <strong>End:</strong> ${endLocation}
      </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
      <div style="background: #f3f4f6; padding: 10px; border-radius: 6px; text-align: center;">
        <div style="font-size: 12px; color: #6b7280;">Distance</div>
        <div style="font-weight: 700; color: #2563eb; font-size: 16px;">${distance} km</div>
      </div>
      <div style="background: #f3f4f6; padding: 10px; border-radius: 6px; text-align: center;">
        <div style="font-size: 12px; color: #6b7280;">Duration</div>
        <div style="font-weight: 700; color: #2563eb; font-size: 16px;">${duration} min</div>
      </div>
    </div>
  `;

  map.controls[google.maps.ControlPosition.TOP_LEFT].push(infoBox);
}
