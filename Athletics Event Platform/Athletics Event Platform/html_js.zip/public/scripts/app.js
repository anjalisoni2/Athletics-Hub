// app.js
// Main Application Logic
// LOGIC NOT CHANGED – ONLY MODULE COMPATIBILITY FIXED

/* ================= IMPORTS ================= */

// Views
import { renderLandingPage } from "./views/landing.js";
import { renderEventsPage, renderEventResults } from "./views/events.js";
import { renderEventDetails } from "./views/event-details.js";
import { renderAthleteDashboard } from "./views/athlete-dashboard.js";
import { renderOrganizerDashboard } from "./views/organizer-dashboard.js";
import { renderAdminPanel } from "./views/admin-panel.js";
import { renderLiveTracking } from "./views/live-tracking.js";
import { renderUserStatistics } from "./views/user-statistics.js";
import { renderOrganizersReport } from "./views/organizers-report.js";
import { renderFitnessDashboard } from "./views/fitness-dashboard.js";
import { renderResultsLeaderboard } from "./views/results-leaderboard.js";

// Shared
import "./data.js";
import { createElement, createIcon, switchTab } from "./utils.js";

/* ================= GLOBAL STATE ================= */

let currentView = "landing";
let userRole = "guest";
let selectedEventId = null;

/* ================= GLOBAL FUNCTIONS ================= */

// Make utility functions globally available for inline onclick handlers
window.switchTab = switchTab;

window.goToDashboard = function() {
    if (userRole === "athlete") navigateTo("athlete-dashboard");
    else if (userRole === "organizer") navigateTo("organizer-dashboard");
    else if (userRole === "admin" || userRole === "superadmin") navigateTo("admin-panel");
    else navigateTo("landing");
};

/* ================= INIT ================= */

document.addEventListener("DOMContentLoaded", function () {
    // Check if user is logged in
    const currentUser = localStorage.getItem("currentUser");
    if (currentUser) {
        const users = JSON.parse(localStorage.getItem("users")) || {};
        if (users[currentUser]) {
            // Set user role based on stored data
            let role = users[currentUser].role;
            if (role === "participant") {
                userRole = "athlete";
            } else {
                userRole = role;
            }
            
            // Auto-navigate to dashboard based on role
            if (userRole === "athlete") navigateTo("athlete-dashboard");
            else if (userRole === "organizer") navigateTo("organizer-dashboard");
            else if (userRole === "admin" || userRole === "superadmin") navigateTo("admin-panel");
            else navigateTo("landing");
        } else {
            navigateTo("landing");
        }
    } else {
        navigateTo("landing");
    }
});

/* ================= NAVIGATION ================= */

window.navigateTo = async function (view, eventId = null) {
    currentView = view;
    if (eventId) selectedEventId = eventId;

    const app = document.getElementById("app");
    const navigation = document.getElementById("navigation");

    // Always show navigation and update it
    navigation.classList.remove("hidden");
    updateNavigation();

    // Clear current content
    app.innerHTML = "";

    // Load view
    switch (view) {
        case "landing":
            renderLandingPage(app);
            break;
        case "events":
            renderEventsPage(app);
            break;
        case "event-details":
            await renderEventDetails(app, selectedEventId);
            break;
        case "view-results":
            await renderEventResults(app, selectedEventId);
            break;
        case "athlete-dashboard":
            await renderAthleteDashboard(app);
            break;
        case "organizer-dashboard":
            await renderOrganizerDashboard(app);
            break;
        case "admin-panel":
            renderAdminPanel(app);
            break;
        case "user-statistics":
            await renderUserStatistics(app);
            break;
        case "organizers-report":
            await renderOrganizersReport(app);
            break;
        case "live-tracking":
            // For athletes, show fitness dashboard; otherwise show live tracking
            if (userRole === "athlete") {
                await renderFitnessDashboard(app);
            } else {
                renderLiveTracking(app);
            }
            break;
        case "fitness-dashboard":
            await renderFitnessDashboard(app);
            break;
        case "results-leaderboard":
            renderResultsLeaderboard(app, selectedEventId);
            break;
        default:
            renderLandingPage(app);
    }

    window.scrollTo(0, 0);
};

/* ================= AUTH ================= */

window.login = function (role) {
    // Map "participant" to "athlete" for consistency
    if (role === "participant") {
        userRole = "athlete";
    } else {
        userRole = role;
    }

    if (userRole === "athlete") navigateTo("athlete-dashboard");
    else if (userRole === "organizer") navigateTo("organizer-dashboard");
    else if (userRole === "admin" || userRole === "superadmin") navigateTo("admin-panel");
};

function logout() {
    userRole = "guest";
    localStorage.removeItem("currentUser");
    navigateTo("landing");
}

/* ================= NAV BAR ================= */


function updateNavigation() {
    const navLinks = document.getElementById("navbarLinks");
    navLinks.innerHTML = "";

    
    // Show Create Event button only for organizers (not for super admin)
    if (userRole === "organizer") {
        const createEventBtn = createElement("button", "btn btn-primary btn-sm");
        createEventBtn.appendChild(createIcon("plus"));
        createEventBtn.appendChild(document.createTextNode(" Create Event"));
        createEventBtn.onclick = () => {
            window.location.href = "event.html";
        };
        navLinks.appendChild(createEventBtn);
    }

    const homeBtn = createElement("button", "btn btn-ghost btn-sm");
    homeBtn.appendChild(createIcon("home"));
    homeBtn.appendChild(document.createTextNode(" Home"));
    homeBtn.onclick = () => navigateTo("landing");
    navLinks.appendChild(homeBtn);

    const eventsBtn = createElement("button", "btn btn-ghost btn-sm");
    eventsBtn.appendChild(createIcon("calendar"));
    eventsBtn.appendChild(document.createTextNode(" Events"));
    eventsBtn.onclick = () => navigateTo("events");
    navLinks.appendChild(eventsBtn);

    // Show Live button for athletes and organizers
    if (userRole === "athlete" || userRole === "organizer") {
        const liveBtn = createElement("button", "btn btn-ghost btn-sm");
        liveBtn.appendChild(createIcon("radio"));
        liveBtn.appendChild(document.createTextNode(" Live"));
        liveBtn.onclick = () => navigateTo("live-tracking");
        navLinks.appendChild(liveBtn);
    }

    if (userRole !== "guest") {
        // Add profile avatar
        const currentUser = localStorage.getItem("currentUser");
        if (currentUser) {
            const users = JSON.parse(localStorage.getItem("users")) || {};
            const userData = users[currentUser];

            if (userData) {
                const profileAvatar = document.createElement("div");
                const userInitial = currentUser.charAt(0).toUpperCase();

                // Determine avatar color based on role
                let avatarClass = "profile-avatar profile-avatar-blue";
                if (userData.role === "organizer") {
                    avatarClass = "profile-avatar profile-avatar-purple";
                } else if (userData.role === "superadmin") {
                    avatarClass = "profile-avatar profile-avatar-green";
                }

                profileAvatar.className = avatarClass;
                profileAvatar.textContent = userInitial;
                profileAvatar.title = `${userData.firstName} ${userData.lastName}`;
                profileAvatar.style.cursor = "pointer";
                profileAvatar.onclick = () => {
                    if (userData.role === "organizer") {
                        navigateTo('organizer-dashboard');
                    } else if (userData.role === "superadmin" || userData.role === "admin") {
                        navigateTo('admin-panel');
                    } else if (userData.role === "participant" || userData.role === "athlete") {
                        navigateTo('athlete-dashboard');
                    } else {
                        navigateTo('landing');
                    }
                };
                navLinks.appendChild(profileAvatar);
            }
        }

        // Only show logout on athlete dashboard, not on landing page
        if (currentView !== "landing") {
            const logoutBtn = createElement("button", "btn btn-outline btn-sm");
            logoutBtn.appendChild(createIcon("logout"));
            logoutBtn.appendChild(document.createTextNode(" Logout"));
            logoutBtn.onclick = logout;
            navLinks.appendChild(logoutBtn);
        }
    }
}
